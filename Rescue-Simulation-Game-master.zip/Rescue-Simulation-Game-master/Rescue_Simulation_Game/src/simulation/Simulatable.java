package simulation;

import model.disasters.Disaster;

public interface Simulatable {
	public void cycleStep();
}
