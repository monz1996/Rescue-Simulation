# Rescue Simulation Game
The game is a single player one, where the player is responsible for managing the rescue units to handle buildings and citizens suffering from the disasters that ensue during game-play throughout the whole map to rescue as many citizens and buildings as possible.

# Acknowledgment
This project outline was designed by the MET department at the German University in Cairo [link](http://met.guc.edu.eg/Download.ashx?id=28726&file=Rescue%20Simulation%20Description_28726.pdf).
